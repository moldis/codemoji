window.OnBoardingAnimations = {};


/* template


;(function (window, OnBoardingAnimations, $, undefined) {

	var oo = OnBoardingAnimations

	oo.scene_01 = {}

	function enter(clb){
		
	}

	function exit(clb){
		
	}

	oo.scene_01.enter = enter
	oo.scene_01.exit = exit

})(window, window.OnBoardingAnimations, window.jQuery); 


*/