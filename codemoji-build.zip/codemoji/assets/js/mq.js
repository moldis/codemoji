;(function (window, Cryptoloji, undefined) {

  Cryptoloji.mq = window.matchMedia("screen and (min-width: 1024px)")

})(window, window.Cryptoloji); 
