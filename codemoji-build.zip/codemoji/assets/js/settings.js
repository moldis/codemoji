;(function (window, Cryptoloji, undefined) {
  
  Cryptoloji.settings = {
    inputMaxSize: 120,
    captcha: {
      url: 'http://el.s.todo.to.it:3000',
      sitekey: '6Lc0txgTAAAAAPSW9_GalyD8WjVaDHONcbgH0oYe'
    }
  }

})(window, window.Cryptoloji); 
